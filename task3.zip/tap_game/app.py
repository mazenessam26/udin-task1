from flask import Flask, render_template, session, jsonify, request
import secrets
from game_state import GameState, start_game_timer

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Initialize global game state
game_state = GameState()

# Start the background game timer thread
start_game_timer(game_state)

# =============================================================================
# FLASK ROUTES
# =============================================================================

@app.route('/')
def index():
    """Serve the main game page"""
    # Generate unique player ID if new session
    if 'player_id' not in session:
        session['player_id'] = secrets.token_hex(8)
        print(f"👤 New player joined: {session['player_id']}")
    
    # Register player in game state
    game_state.register_player(session['player_id'])
    
    return render_template('index.html')

@app.route('/api/game_status')
def game_status():
    """Return current game state to clients"""
    player_id = session.get('player_id')
    response = game_state.get_status(player_id)
    return jsonify(response)

@app.route('/api/tap', methods=['POST'])
def tap():
    """Record a tap from a player"""
    player_id = session.get('player_id')
    success, count = game_state.record_tap(player_id)
    
    if success:
        return jsonify({'success': True, 'count': count})
    else:
        return jsonify({'success': False, 'reason': 'Game not active'})

@app.route('/api/restart', methods=['POST'])
def restart():
    """Restart the game"""
    game_state.restart_game()
    return jsonify({'success': True})

# =============================================================================
# RUN THE APPLICATION
# =============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("🎮 TAP COMPETITION GAME SERVER")
    print("=" * 60)
    print("📡 Server starting on http://127.0.0.1:5000")
    print("👥 Open TWO browser tabs to http://127.0.0.1:5000")
    print("⏰ Game starts automatically when 2 players join")
    print("=" * 60)
    
    app.run(debug=True, host='127.0.0.1', port=5000, threaded=True)
