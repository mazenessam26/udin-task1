from datetime import datetime
import threading
import time

class GameState:
    """Manages the game state and timing for the tap competition"""
    
    def __init__(self):
        """Initialize game state"""
        self.start_time = None          # UTC time when game starts
        self.game_duration = 15         # Game duration in seconds
        self.players = {}               # {player_id: tap_count}
        self.game_active = False        # Is game currently running
        self.game_over = False          # Has game ended
        self.winner = None              # Winner information
        self.waiting_for_players = True # Waiting for players to join
        self.lock = threading.Lock()    # Thread-safe operations
    
    def register_player(self, player_id):
        """Register a new player in the game"""
        with self.lock:
            if player_id not in self.players:
                self.players[player_id] = 0
                print(f"📊 Total players: {len(self.players)}")
    
    def record_tap(self, player_id):
        """Record a tap from a player"""
        with self.lock:
            # Only count taps during active game
            if self.game_active and player_id in self.players:
                self.players[player_id] += 1
                return True, self.players[player_id]
            else:
                return False, 0
    
    def get_status(self, player_id):
        """Get current game status for a specific player"""
        with self.lock:
            # Calculate time remaining
            time_remaining = 0
            if self.start_time and self.game_active:
                elapsed = (datetime.utcnow() - self.start_time).total_seconds()
                time_remaining = max(0, self.game_duration - elapsed)
            
            return {
                'player_id': player_id,
                'game_active': self.game_active,
                'game_over': self.game_over,
                'waiting_for_players': self.waiting_for_players,
                'time_remaining': time_remaining,
                'my_score': self.players.get(player_id, 0),
                'all_scores': self.players.copy(),
                'winner': self.winner,
                'start_time': self.start_time.isoformat() if self.start_time else None
            }
    
    def start_game(self):
        """Start the game"""
        with self.lock:
            print("🎮 Starting game with 2 players!")
            self.start_time = datetime.utcnow()
            self.game_active = True
            self.game_over = False
            self.waiting_for_players = False
            self.winner = None
            print(f"⏰ Game start time: {self.start_time}")
    
    def end_game(self):
        """End the game and determine winner"""
        with self.lock:
            print("⏱️ Time's up! Calculating winner...")
            self.game_active = False
            self.game_over = True
            
            # Determine winner
            if self.players:
                winner_id = max(self.players, key=self.players.get)
                winner_score = self.players[winner_id]
                
                self.winner = {
                    'player_id': winner_id,
                    'score': winner_score
                }
                print(f"🏆 Winner: Player {winner_id[:8]} with {winner_score} taps!")
            else:
                self.winner = None
    
    def restart_game(self):
        """Reset the game state for a new round"""
        with self.lock:
            print("🔄 Game restart requested!")
            self.start_time = None
            self.game_active = False
            self.game_over = False
            self.winner = None
            self.waiting_for_players = True
            
            # Reset all player scores
            for player_id in self.players:
                self.players[player_id] = 0
            
            print("✅ Game reset complete. Waiting for players...")
    
    def should_start(self):
        """Check if game should start"""
        with self.lock:
            return (self.waiting_for_players and 
                    len(self.players) >= 2 and 
                    not self.game_active)
    
    def should_end(self):
        """Check if game should end"""
        with self.lock:
            if self.game_active and self.start_time:
                elapsed = (datetime.utcnow() - self.start_time).total_seconds()
                return elapsed >= self.game_duration
            return False


def game_timer_thread(game_state):
    """Background thread that manages game timing"""
    while True:
        time.sleep(0.5)  # Check every half second
        
        # Start game when we have 2 players
        if game_state.should_start():
            game_state.start_game()
        
        # Check if game should end
        if game_state.should_end():
            game_state.end_game()


def start_game_timer(game_state):
    """Start the game timer background thread"""
    timer_thread = threading.Thread(target=game_timer_thread, 
                                    args=(game_state,), 
                                    daemon=True)
    timer_thread.start()
    print("⚙️ Game timer thread started")
