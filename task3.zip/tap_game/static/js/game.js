// =================================================================
// CLIENT STATE - Synchronized with server
// =================================================================

let myPlayerId = null;
let myScore = 0;
let gameActive = false;
let updateInterval = null;

// =================================================================
// DOM ELEMENTS
// =================================================================

const tapButton = document.getElementById('tapButton');
const scoreDisplay = document.getElementById('score');
const timerDisplay = document.getElementById('timer');
const statusDisplay = document.getElementById('status');
const winnerDisplay = document.getElementById('winner');
const restartButton = document.getElementById('restartButton');
const playerIdDisplay = document.getElementById('playerId');
const scoreboardDiv = document.getElementById('scoreboard');
const allScoresDiv = document.getElementById('allScores');

// =================================================================
// TAP HANDLER - Send tap to server
// =================================================================

tapButton.addEventListener('click', async () => {
    if (!gameActive) return;
    
    try {
        const response = await fetch('/api/tap', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        
        const data = await response.json();
        
        if (data.success) {
            myScore = data.count;
            scoreDisplay.textContent = myScore;
        }
    } catch (error) {
        console.error('Error recording tap:', error);
    }
});

// =================================================================
// RESTART HANDLER
// =================================================================

restartButton.addEventListener('click', async () => {
    try {
        await fetch('/api/restart', { method: 'POST' });
        restartButton.style.display = 'none';
        winnerDisplay.style.display = 'none';
        scoreboardDiv.style.display = 'none';
    } catch (error) {
        console.error('Error restarting game:', error);
    }
});

// =================================================================
// GAME STATUS UPDATE - Poll server for synchronized state
// =================================================================

async function updateGameStatus() {
    try {
        const response = await fetch('/api/game_status');
        const data = await response.json();
        
        // Update player ID
        if (data.player_id && !myPlayerId) {
            myPlayerId = data.player_id;
            playerIdDisplay.textContent = myPlayerId.substring(0, 8);
        }
        
        // Update score
        myScore = data.my_score;
        scoreDisplay.textContent = myScore;
        
        // Update timer
        if (data.time_remaining > 0) {
            const seconds = Math.ceil(data.time_remaining);
            timerDisplay.textContent = `${seconds}s`;
        } else if (data.game_over) {
            timerDisplay.textContent = '0s';
        } else {
            timerDisplay.textContent = '--:--';
        }
        
        // Update game state
        if (data.waiting_for_players) {
            statusDisplay.textContent = `Waiting for players... (${Object.keys(data.all_scores).length}/2)`;
            tapButton.disabled = true;
            gameActive = false;
        } else if (data.game_active) {
            statusDisplay.textContent = '🎮 Game in progress! TAP AS FAST AS YOU CAN! 🎮';
            tapButton.disabled = false;
            gameActive = true;
        } else if (data.game_over) {
            statusDisplay.textContent = 'Game Over!';
            tapButton.disabled = true;
            gameActive = false;
            
            // Show winner
            if (data.winner) {
                const isWinner = data.winner.player_id === myPlayerId;
                if (isWinner) {
                    winnerDisplay.textContent = `🏆 YOU WIN! 🏆 (${data.winner.score} taps)`;
                } else {
                    winnerDisplay.textContent = `Player ${data.winner.player_id.substring(0, 8)} wins with ${data.winner.score} taps`;
                }
                winnerDisplay.style.display = 'block';
            }
            
            // Show scoreboard
            let scoresHtml = '';
            for (const [pid, score] of Object.entries(data.all_scores)) {
                const isMe = pid === myPlayerId;
                scoresHtml += `<div style="margin: 5px 0; ${isMe ? 'font-weight: bold;' : ''}">
                    Player ${pid.substring(0, 8)}${isMe ? ' (You)' : ''}: ${score} taps
                </div>`;
            }
            allScoresDiv.innerHTML = scoresHtml;
            scoreboardDiv.style.display = 'block';
            
            // Show restart button
            restartButton.style.display = 'inline-block';
        }
        
    } catch (error) {
        console.error('Error updating game status:', error);
        statusDisplay.textContent = 'Connection error...';
    }
}

// =================================================================
// INITIALIZATION - Start polling server
// =================================================================

// Update status every 100ms for smooth timer
updateInterval = setInterval(updateGameStatus, 100);

// Initial update
updateGameStatus();

console.log('🎮 Tap Competition initialized!');



