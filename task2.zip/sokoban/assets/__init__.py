import os
import pygame
from config import TILE_SIZE  # using your existing config

def load_all_assets():
    """Load and scale all PNG assets from the assets folder."""
    assets = {}
    base_path = os.path.dirname(__file__)

    def load_image(name):
        path = os.path.join(base_path, f"{name}.png")
        if os.path.exists(path):
            image = pygame.image.load(path).convert_alpha()
            # ✅ Scale image to half the tile size
            scaled_size = int(TILE_SIZE)
            image = pygame.transform.scale(image, (scaled_size, scaled_size))
            return image
        return None

    # Load all game elements
    assets['player'] = load_image('player')
    assets['wall'] = load_image('wall')
    assets['box'] = load_image('box')
    assets['box_on_goal'] = load_image('box_on_goal')
    assets['goal'] = load_image('goal')
    assets['floor'] = load_image('floor')

    print("✅ Assets loaded & scaled:", [k for k, v in assets.items() if v])
    return assets
