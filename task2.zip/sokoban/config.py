# Game Configuration and Constants

# Window settings
TILE_SIZE = 64
GRID_WIDTH = 10
GRID_HEIGHT = 10
WINDOW_WIDTH = GRID_WIDTH * TILE_SIZE
WINDOW_HEIGHT = GRID_HEIGHT * TILE_SIZE +50
FPS = 60

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)
BROWN = (139, 69, 19)
YELLOW = (255, 215, 0)
GREEN = (34, 139, 34)
BLUE = (70, 130, 180)
DARK_GREEN = (0, 100, 0)
RED = (200, 50, 50)
DARK_GRAY = (50, 50, 50)

# User database (in-memory)
users_db = {
    'admin': {'password': 'admin123', 'role': 'admin'},
    'player1': {'password': 'pass123', 'role': 'player'}
}