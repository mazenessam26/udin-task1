import pygame
import sys
import os
import json
from config import *

# RED = main.RED
# GREEN = main.GREEN
# BLACK = main.BLACK
# WHITE = main.WHITE
# BLUE = main.BLUE
# YELLOW = main.YELLOW
# GRAY = main.GRAY
# DARK_GRAY = main.DARK_GRAY
# BROWN = main.BROWN
# users_db = config.users_db
# WINDOW_WIDTH = config.WINDOW_WIDTH
# WINDOW_HEIGHT = config.WINDOW_HEIGHT
# GRID_WIDTH = config.GRID_WIDTH
# GRID_HEIGHT = config.GRID_HEIGHT
# TILE_SIZE = config.TILE_SIZE
class LoginMenu:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 24)
        self.username_input = ""
        self.password_input = ""
        self.active_field = "username"
        self.mode = "login"
        self.message = ""
        self.message_color = WHITE
        
    def handle_input(self, event):
        """Handle keyboard input for login/register"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_TAB:
                self.active_field = "password" if self.active_field == "username" else "username"
            elif event.key == pygame.K_RETURN:
                return self.submit()
            elif event.key == pygame.K_BACKSPACE:
                if self.active_field == "username":
                    self.username_input = self.username_input[:-1]
                else:
                    self.password_input = self.password_input[:-1]
            elif event.key == pygame.K_b:
                self.mode = "register" if self.mode == "login" else "login"
                self.message = f"Switched to {self.mode.upper()} mode"
                self.message_color = WHITE
            else:
                if len(event.unicode) > 0 and event.unicode.isprintable():
                    if self.active_field == "username":
                        self.username_input += event.unicode
                    else:
                        self.password_input += event.unicode
        return None
    
    def submit(self):
        """Process login or registration"""
        username = self.username_input.strip()
        password = self.password_input
        
        if not username or not password:
            self.message = "Username and password required!"
            self.message_color = RED
            return None
        
        if self.mode == "login":
            if username in users_db:
                if users_db[username]['password'] == password:
                    self.message = "Login successful!"
                    self.message_color = GREEN
                    return {'username': username, 'role': users_db[username]['role']}
                else:
                    self.message = "Invalid password!"
                    self.message_color = RED
            else:
                self.message = "User not found!"
                self.message_color = RED
        else:
            if username in users_db:
                self.message = "Username already exists!"
                self.message_color = RED
            else:
                users_db[username] = {'password': password, 'role': 'player'}
                self.message = "Registration successful! Press b to login."
                self.message_color = GREEN
        
        return None
    
    def draw(self):
        """Draw the login/register menu"""
        self.screen.fill(BLACK)
        
        title = self.font.render(f"{self.mode.upper()}", True, WHITE)
        self.screen.blit(title, (WINDOW_WIDTH // 2 - title.get_width() // 2, 100))
        
        username_label = self.small_font.render("Username:", True, WHITE)
        self.screen.blit(username_label, (150, 200))
        
        username_color = BLUE if self.active_field == "username" else GRAY
        username_rect = pygame.Rect(150, 230, 340, 40)
        pygame.draw.rect(self.screen, username_color, username_rect, 2)
        username_text = self.small_font.render(self.username_input, True, WHITE)
        self.screen.blit(username_text, (160, 240))
        
        password_label = self.small_font.render("Password:", True, WHITE)
        self.screen.blit(password_label, (150, 300))
        
        password_color = BLUE if self.active_field == "password" else GRAY
        password_rect = pygame.Rect(150, 330, 340, 40)
        pygame.draw.rect(self.screen, password_color, password_rect, 2)
        password_display = "*" * len(self.password_input)
        password_text = self.small_font.render(password_display, True, WHITE)
        self.screen.blit(password_text, (160, 340))
        
        instructions = [
            "TAB: Switch field",
            "ENTER: Submit",
            "b: Toggle Login/Register",
            "ESC: Continue as Anonymous"
        ]
        y = 420
        for instruction in instructions:
            text = self.small_font.render(instruction, True, GRAY)
            self.screen.blit(text, (150, y))
            y += 30
        
        if self.message:
            msg = self.small_font.render(self.message, True, self.message_color)
            self.screen.blit(msg, (WINDOW_WIDTH // 2 - msg.get_width() // 2, 580))
        
        pygame.display.flip()