import pygame
import sys
import os
import json
from config import *

# RED = main.RED
# GREEN = main.GREEN
# BLACK = main.BLACK
# WHITE = main.WHITE
# BLUE = main.BLUE
# YELLOW = main.YELLOW
# GRAY = main.GRAY
# DARK_GRAY = main.DARK_GRAY
# BROWN = main.BROWN
# users_db = config.users_db
# WINDOW_WIDTH = config.WINDOW_WIDTH
# WINDOW_HEIGHT = config.WINDOW_HEIGHT
# GRID_WIDTH = config.GRID_WIDTH
# GRID_HEIGHT = config.GRID_HEIGHT
# TILE_SIZE = config.TILE_SIZE
class MainMenu:
    def __init__(self, screen, username, role):
        self.screen = screen
        self.username = username
        self.role = role
        self.font = pygame.font.Font(None, 48)
        self.small_font = pygame.font.Font(None, 28)
        self.selected = 0
        
        # Define menu options based on role
        if role == "admin":
            self.options = ["Play Game", "View Leaderboard", "Admin Tools", "Logout"]
        elif role == "player":
            self.options = ["Play Game", "View Leaderboard", "Logout"]
        else:  # anonymous
            self.options = ["View Leaderboard", "Login", "Exit"]
    
    def handle_input(self, event):
        """Handle menu navigation"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_o:
                self.selected = (self.selected - 1) % len(self.options)
            elif event.key == pygame.K_k:
                self.selected = (self.selected + 1) % len(self.options)
            elif event.key == pygame.K_RETURN:
                return self.options[self.selected]
        return None
    
    def draw(self):
        """Draw the main menu"""
        self.screen.fill(BLACK)
        
        # Title
        title = self.font.render("SOKOBAN", True, YELLOW)
        self.screen.blit(title, (WINDOW_WIDTH // 2 - title.get_width() // 2, 80))
        
        # User info
        user_info = self.small_font.render(f"User: {self.username} ({self.role})", True, WHITE)
        self.screen.blit(user_info, (WINDOW_WIDTH // 2 - user_info.get_width() // 2, 140))
        
        # Menu options
        y = 220
        for i, option in enumerate(self.options):
            color = GREEN if i == self.selected else WHITE
            text = self.small_font.render(f"> {option}" if i == self.selected else f"  {option}", True, color)
            self.screen.blit(text, (WINDOW_WIDTH // 2 - text.get_width() // 2, y))
            y += 50
        
        # Instructions
        instructions = self.small_font.render("Use o/k and ENTER", True, GRAY)
        self.screen.blit(instructions, (WINDOW_WIDTH // 2 - instructions.get_width() // 2, 520))
        
        pygame.display.flip()