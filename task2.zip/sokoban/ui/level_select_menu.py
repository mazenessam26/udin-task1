import os
import pygame
from config import *

class LevelSelectMenu:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.Font(None, 48)
        self.small_font = pygame.font.Font(None, 28)
        self.selected = 0
        self.levels = self.load_levels()

    def load_levels(self):
        """Return a list of all .txt level files in the levels/ folder"""
        levels_dir = "levels"
        if not os.path.exists(levels_dir):
            os.makedirs(levels_dir)
        files = [f for f in os.listdir(levels_dir) if f.endswith(".txt")]
        return sorted(files) if files else ["No levels found"]

    def handle_input(self, event):
        """Handle keyboard input for navigating level list"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_o:
                self.selected = (self.selected - 1) % len(self.levels)
            elif event.key == pygame.K_k:
                self.selected = (self.selected + 1) % len(self.levels)
            elif event.key == pygame.K_RETURN:
                if self.levels[self.selected] != "No levels found":
                    return self.levels[self.selected]
        return None

    def draw(self):
        """Draw the level selection screen"""
        self.screen.fill(BLACK)
        
        title = self.font.render("SELECT LEVEL", True, YELLOW)
        self.screen.blit(title, (WINDOW_WIDTH // 2 - title.get_width() // 2, 80))
        
        y = 200
        for i, level in enumerate(self.levels):
            color = GREEN if i == self.selected else WHITE
            text = self.small_font.render(f"> {level}" if i == self.selected else f"  {level}", True, color)
            self.screen.blit(text, (WINDOW_WIDTH // 2 - text.get_width() // 2, y))
            y += 40
        
        instructions = self.small_font.render("Use o/k to move, ENTER to select, ESC to return", True, GRAY)
        self.screen.blit(instructions, (WINDOW_WIDTH // 2 - instructions.get_width() // 2, 520))
        
        pygame.display.flip()
