import pygame
import sys
import os
import json
from config import *

# RED = main.RED
# GREEN = main.GREEN
# BLACK = main.BLACK
# WHITE = main.WHITE
# BLUE = main.BLUE
# YELLOW = main.YELLOW
# GRAY = main.GRAY
# DARK_GRAY = main.DARK_GRAY
# BROWN = main.BROWN
# users_db = config.users_db
# WINDOW_WIDTH = config.WINDOW_WIDTH
# WINDOW_HEIGHT = config.WINDOW_HEIGHT
# GRID_WIDTH = config.GRID_WIDTH
# GRID_HEIGHT = config.GRID_HEIGHT
# TILE_SIZE = config.TILE_SIZE

class LevelCreator:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.Font(None, 28)
        self.grid = [[' ' for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]
        self.selected_tile = '#'  # wall
        self.cursor_x = 0
        self.cursor_y = 0
        self.tiles = ['#', '$', '*', '@', ' ']
        self.tile_names = {'#': 'Wall', '$': 'Box', '*': 'Goal', '@': 'Player', ' ': 'Empty'}
        self.message = ""
        
        # Add borders
        for x in range(GRID_WIDTH):
            self.grid[0][x] = '#'
            self.grid[GRID_HEIGHT-1][x] = '#'
        for y in range(GRID_HEIGHT):
            self.grid[y][0] = '#'
            self.grid[y][GRID_WIDTH-1] = '#'
    
    def handle_input(self, event):
        """Handle level creator input"""
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                self.cursor_y = max(0, self.cursor_y - 1)
            elif event.key == pygame.K_s:
                self.cursor_y = min(GRID_HEIGHT - 1, self.cursor_y + 1)
            elif event.key == pygame.K_a:
                self.cursor_x = max(0, self.cursor_x - 1)
            elif event.key == pygame.K_d:
                self.cursor_x = min(GRID_WIDTH - 1, self.cursor_x + 1)
            elif event.key == pygame.K_SPACE:
                self.grid[self.cursor_y][self.cursor_x] = self.selected_tile
            elif event.key == pygame.K_TAB:
                current_index = self.tiles.index(self.selected_tile)
                self.selected_tile = self.tiles[(current_index + 1) % len(self.tiles)]
            elif event.key == pygame.K_l:
                self.save_level()
            elif event.key == pygame.K_c:
                self.clear_grid()
    
    def clear_grid(self):
        """Clear the grid except borders"""
        for y in range(1, GRID_HEIGHT - 1):
            for x in range(1, GRID_WIDTH - 1):
                self.grid[y][x] = ' '
        self.message = "Grid cleared!"
    
    def save_level(self):
        """Save level to file"""
        # Create levels directory if it doesn't exist
        if not os.path.exists('levels'):
            os.makedirs('levels')
        
        # Validate level
        player_count = sum(row.count('@') for row in self.grid)
        box_count = sum(row.count('$') for row in self.grid)
        goal_count = sum(row.count('*') for row in self.grid)
        
        if player_count != 1:
            self.message = "Error: Need exactly 1 player!"
            return
        if box_count == 0 or goal_count == 0:
            self.message = "Error: Need at least 1 box and 1 goal!"
            return
        if box_count != goal_count:
            self.message = "Warning: Box count != Goal count"
        
        # Find next level number
        level_num = 1
        while os.path.exists(f'levels/level{level_num}.txt'):
            level_num += 1
        
        filename = f'levels/level{level_num}.txt'
        try:
            with open(filename, 'w') as f:
                for row in self.grid:
                    f.write(''.join(row) + '\n')
            self.message = f"Saved as {filename}!"
        except Exception as e:
            self.message = f"Error saving: {e}"
    
    def draw(self):
        """Draw the level creator"""
        self.screen.fill(BLACK)
        
        # Draw grid
        for y in range(GRID_HEIGHT):
            for x in range(GRID_WIDTH):
                rect = pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                
                # Background
                pygame.draw.rect(self.screen, GRAY, rect)
                pygame.draw.rect(self.screen, DARK_GRAY, rect, 1)
                
                # Cursor highlight
                if x == self.cursor_x and y == self.cursor_y:
                    pygame.draw.rect(self.screen, GREEN, rect, 3)
                
                # Draw tile
                char = self.grid[y][x]
                if char == '#':
                    pygame.draw.rect(self.screen, BROWN, rect.inflate(-10, -10))
                elif char == '$':
                    pygame.draw.rect(self.screen, YELLOW, rect.inflate(-20, -20))
                elif char == '*':
                    pygame.draw.circle(self.screen, GREEN, rect.center, 15)
                elif char == '@':
                    pygame.draw.rect(self.screen, BLUE, rect.inflate(-25, -25))
        
        # Draw info panel
        info_bg = pygame.Rect(0, GRID_HEIGHT * TILE_SIZE, WINDOW_WIDTH, 50)
        pygame.draw.rect(self.screen, BLACK, info_bg)
        
        info_text = f"Selected: {self.tile_names[self.selected_tile]} | TAB: Change | SPACE: Place | L: Save | C: Clear | ESC: Exit"
        text = self.font.render(info_text, True, WHITE)
        self.screen.blit(text, (10, GRID_HEIGHT * TILE_SIZE + 10))
        
        if self.message:
            msg_color = GREEN if "Saved" in self.message else RED
            msg = self.font.render(self.message, True, msg_color)
            self.screen.blit(msg, (10, GRID_HEIGHT * TILE_SIZE + 30))
        
        pygame.display.flip()