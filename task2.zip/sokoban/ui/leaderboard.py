import pygame
import sys
import os
import json
import config

RED = config.RED
GREEN = config.GREEN
BLACK = config.BLACK
WHITE = config.WHITE
BLUE = config.BLUE
YELLOW = config.YELLOW
GRAY = config.GRAY
DARK_GRAY = config.DARK_GRAY
BROWN = config.BROWN
users_db = config.users_db
WINDOW_WIDTH = config.WINDOW_WIDTH
WINDOW_HEIGHT = config.WINDOW_HEIGHT
GRID_WIDTH = config.GRID_WIDTH
GRID_HEIGHT = config.GRID_HEIGHT
TILE_SIZE = config.TILE_SIZE
class LeaderboardView:
    def __init__(self, screen, score_manager):
        self.screen = screen
        self.score_manager = score_manager
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 28)
    
    def draw(self):
        """Draw the leaderboard"""
        self.screen.fill(BLACK)
        
        title = self.font.render("LEADERBOARD", True, YELLOW)
        self.screen.blit(title, (WINDOW_WIDTH // 2 - title.get_width() // 2, 50))
        
        subtitle = self.small_font.render("(Fewest Moves)", True, GRAY)
        self.screen.blit(subtitle, (WINDOW_WIDTH // 2 - subtitle.get_width() // 2, 90))
        
        leaderboard = self.score_manager.get_leaderboard()
        
        if not leaderboard:
            no_scores = self.small_font.render("No scores yet!", True, WHITE)
            self.screen.blit(no_scores, (WINDOW_WIDTH // 2 - no_scores.get_width() // 2, 200))
        else:
            y = 150
            for rank, (username, moves) in enumerate(leaderboard[:10], 1):
                color = YELLOW if rank == 1 else WHITE
                text = self.small_font.render(f"{rank}. {username}: {moves} moves", True, color)
                self.screen.blit(text, (150, y))
                y += 40
        
        instruction = self.small_font.render("Press ESC to return", True, GRAY)
        self.screen.blit(instruction, (WINDOW_WIDTH // 2 - instruction.get_width() // 2, 550))
        
        pygame.display.flip()