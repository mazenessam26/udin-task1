import pygame
import os

def load_all_assets():
    """Load all game images from the assets folder."""
    assets = {
        "floor": None,
        "wall": None,
        "box": None,
        "box_on_goal": None,
        "goal": None,
        "player": None,
    }
    
    # Path to the assets folder
    asset_dir = os.path.join(os.path.dirname(__file__), "assets")

    # Helper to load image safely
    def load_image(filename, scale_to_tile=True):
        path = os.path.join(asset_dir, filename)
        if os.path.exists(path):
            image = pygame.image.load(path).convert_alpha()
            if scale_to_tile:
                from config import TILE_SIZE
                image = pygame.transform.scale(image, (TILE_SIZE, TILE_SIZE))
            return image
        else:
            print(f"Warning: Missing asset '{filename}'")
            return None

    # Load each asset (edit filenames to match your actual PNG names)
    assets["floor"] = load_image("floor.png")
    assets["wall"] = load_image("wall.png")
    assets["box"] = load_image("box.png")
    assets["box_on_goal"] = load_image("box_on_goal.png")
    assets["goal"] = load_image("goal.png")
    assets["player"] = load_image("player.png")

    return assets
