import pygame
import sys
from config import *
from assets import *
from core.score_manager import ScoreManager
from ui.login_menu import LoginMenu
from ui.main_menu import MainMenu
from ui.leaderboard import LeaderboardView
from ui.level_creator import LevelCreator
from ui.level_select_menu import LevelSelectMenu


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Sokoban Clone")
        self.clock = pygame.time.Clock()
        self.running = True
        
        # User info
        self.username = "anonymous"
        self.role = "anonymous"
        
        # Score manager
        self.score_manager = ScoreManager()
        
        # Load assets
        self.assets = load_all_assets()
        
        # Game state
        self.level = []
        self.player_pos = [0, 0]
        self.boxes = []
        self.goals = []
        self.walls = []
        self.moves = 0
        self.current_level_file = None
        
        # Start with login
        self.show_login_menu()
        
        # Main menu loop
        self.main_menu_loop()
        
    
    def show_login_menu(self):
        """Display login/register menu"""
        login_menu = LoginMenu(self.screen)
        in_login = True
        
        while in_login:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                    return
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        in_login = False
                    else:
                        result = login_menu.handle_input(event)
                        if result:
                            self.username = result['username']
                            self.role = result['role']
                            in_login = False
            
            login_menu.draw()
            self.clock.tick(FPS)
    
    def main_menu_loop(self):
        """Main menu loop"""
        while self.running:
            main_menu = MainMenu(self.screen, self.username, self.role)
            in_menu = True
            
            while in_menu and self.running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        self.running = False
                        in_menu = False
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            self.running = False
                            in_menu = False
                        else:
                            choice = main_menu.handle_input(event)
                            if choice:
                                in_menu = False
                                self.handle_menu_choice(choice)
                
                main_menu.draw()
                self.clock.tick(FPS)
    
    def handle_menu_choice(self, choice):
        """Handle menu selection"""
        if choice == "Play Game":
            if self.role == "anonymous":
                return
            self.pick_level()
            
        elif choice == "View Leaderboard":
            self.show_leaderboard()
        elif choice == "Admin Tools":
            if self.role == "admin":
                self.show_level_creator()
        elif choice == "Login":
            self.show_login_menu()
        elif choice == "Logout":
            self.username = "anonymous"
            self.role = "anonymous"
        elif choice == "Exit":
            self.running = False
    
    def pick_level(self):
        # --- Show Level Selection Menu ---
        from ui.level_select_menu import LevelSelectMenu
        level_menu = LevelSelectMenu(self.screen)
        selected_level = None

        while not selected_level:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                result = level_menu.handle_input(event)
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    selected_level = "BACK"
                if result:
                    selected_level = result
            level_menu.draw()

        # --- Load and play the chosen level ---
        if selected_level != "BACK":
            level_path = os.path.join("levels", selected_level)
            self.load_level(level_path)
            self.play_game_loop()
            
    def show_leaderboard(self):
        """Display leaderboard"""
        leaderboard = LeaderboardView(self.screen, self.score_manager)
        viewing = True
        
        while viewing:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                    viewing = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        viewing = False
            
            leaderboard.draw()
            self.clock.tick(FPS)
    
    def show_level_creator(self):
        """Display level creator for admins"""
        creator = LevelCreator(self.screen)
        creating = True
        
        while creating:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                    creating = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        creating = False
                    else:
                        creator.handle_input(event)
            
            creator.draw()
            self.clock.tick(FPS)
    
    def load_level(self, filename):
        """Load level from text file"""
        self.level = []
        self.boxes = []
        self.goals = []
        self.walls = []
        self.moves = 0
        self.current_level_file = filename
        
        try:
            with open(filename, 'r') as f:
                lines = f.readlines()
                for y, line in enumerate(lines):
                    row = []
                    for x, char in enumerate(line.rstrip('\n')):
                        row.append(char)
                        pos = [x, y]
                        
                        if char == '@':
                            self.player_pos = pos
                        elif char == '$':
                            self.boxes.append(pos)
                        elif char == '*':
                            self.goals.append(pos)
                        elif char == '+':
                            self.boxes.append(pos)
                            self.goals.append(pos)
                        elif char == '#':
                            self.walls.append(pos)
                    
                    self.level.append(row)
        except FileNotFoundError:
            self.create_default_level()
    
    def create_default_level(self):
        """Create a simple default level"""
        default = [
            "##########",
            "#        #",
            "#  @     #",
            "#  $  *  #",
            "#  $  *  #",
            "#        #",
            "##########"
        ]
        
        for y, line in enumerate(default):
            row = []
            for x, char in enumerate(line):
                row.append(char)
                pos = [x, y]
                
                if char == '@':
                    self.player_pos = pos
                elif char == '$':
                    self.boxes.append(pos)
                elif char == '*':
                    self.goals.append(pos)
                elif char == '#':
                    self.walls.append(pos)
            
            self.level.append(row)
    
    def move_player(self, dx, dy):
        """Handle player movement and box pushing"""
        new_x = self.player_pos[0] + dx
        new_y = self.player_pos[1] + dy
        new_pos = [new_x, new_y]
        
        if new_pos in self.walls:
            return
        
        if new_pos in self.boxes:
            box_new_x = new_x + dx
            box_new_y = new_y + dy
            box_new_pos = [box_new_x, box_new_y]
            
            if box_new_pos in self.walls or box_new_pos in self.boxes:
                return
            
            box_index = self.boxes.index(new_pos)
            self.boxes[box_index] = box_new_pos
        
        self.player_pos = new_pos
        self.moves += 1
    
    def check_win(self):
        """Check if all boxes are on goals"""
        for box in self.boxes:
            if box not in self.goals:
                return False
        return True
    
    def draw_user_info(self):
        """Draw username, role, and moves at the bottom"""
        font = pygame.font.Font(None, 28)
        user_text = f"User: {self.username} ({self.role}) | Moves: {self.moves}"
        text_surface = font.render(user_text, True, WHITE)
        
        info_rect = pygame.Rect(0, WINDOW_HEIGHT - 50, WINDOW_WIDTH, 50)
        pygame.draw.rect(self.screen, BLACK, info_rect)
        pygame.draw.rect(self.screen, BLUE, info_rect, 2)
        
        self.screen.blit(text_surface, (10, WINDOW_HEIGHT - 40))
    
    def draw_game(self):
        """Draw the game state"""
        self.screen.fill(BLACK)
        
        # Draw floor
        for y in range(len(self.level)):
            for x in range(len(self.level[y])):
                rect = pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                
                if self.assets['floor']:
                    self.screen.blit(self.assets['floor'], (x * TILE_SIZE, y * TILE_SIZE))
                else:
                    pygame.draw.rect(self.screen, GRAY, rect)
                    pygame.draw.rect(self.screen, BLACK, rect, 2)
        
        # Draw goals
        for goal in self.goals:
            if self.assets['goal']:
                self.screen.blit(self.assets['goal'], (goal[0] * TILE_SIZE, goal[1] * TILE_SIZE))
            else:
                rect = pygame.Rect(goal[0] * TILE_SIZE + 10, goal[1] * TILE_SIZE + 10, 
                                 TILE_SIZE - 20, TILE_SIZE - 20)
                pygame.draw.rect(self.screen, DARK_GREEN, rect)
                pygame.draw.circle(self.screen, GREEN, 
                                 (goal[0] * TILE_SIZE + TILE_SIZE // 2, 
                                  goal[1] * TILE_SIZE + TILE_SIZE // 2), 
                                 TILE_SIZE // 3)
        
        # Draw walls
        for wall in self.walls:
            if self.assets['wall']:
                self.screen.blit(self.assets['wall'], (wall[0] * TILE_SIZE, wall[1] * TILE_SIZE))
            else:
                rect = pygame.Rect(wall[0] * TILE_SIZE, wall[1] * TILE_SIZE, 
                                 TILE_SIZE, TILE_SIZE)
                pygame.draw.rect(self.screen, BROWN, rect)
                pygame.draw.rect(self.screen, BLACK, rect, 3)
        
        # Draw boxes
        for box in self.boxes:
            if box in self.goals:
                if self.assets['box_on_goal']:
                    self.screen.blit(self.assets['box_on_goal'], (box[0] * TILE_SIZE, box[1] * TILE_SIZE))
                else:
                    rect = pygame.Rect(box[0] * TILE_SIZE + 8, box[1] * TILE_SIZE + 8, 
                                     TILE_SIZE - 16, TILE_SIZE - 16)
                    pygame.draw.rect(self.screen, YELLOW, rect)
                    pygame.draw.rect(self.screen, BLACK, rect, 3)
            else:
                if self.assets['box']:
                    self.screen.blit(self.assets['box'], (box[0] * TILE_SIZE, box[1] * TILE_SIZE))
                else:
                    rect = pygame.Rect(box[0] * TILE_SIZE + 8, box[1] * TILE_SIZE + 8, 
                                     TILE_SIZE - 16, TILE_SIZE - 16)
                    pygame.draw.rect(self.screen, BROWN, rect)
                    pygame.draw.rect(self.screen, BLACK, rect, 3)
        
        # Draw player
        if self.assets['player']:
            self.screen.blit(self.assets['player'], (self.player_pos[0] * TILE_SIZE, self.player_pos[1] * TILE_SIZE))
        else:
            player_rect = pygame.Rect(self.player_pos[0] * TILE_SIZE + 12, 
                                     self.player_pos[1] * TILE_SIZE + 12, 
                                     TILE_SIZE - 24, TILE_SIZE - 24)
            pygame.draw.rect(self.screen, BLUE, player_rect)
            pygame.draw.rect(self.screen, WHITE, player_rect, 3)
        
        # Draw win message
        if self.check_win():
            font = pygame.font.Font(None, 74)
            text = font.render("Level Complete!", True, WHITE)
            text_rect = text.get_rect(center=(WINDOW_WIDTH // 2, (WINDOW_HEIGHT - 50) // 2))
            bg_rect = text_rect.inflate(20, 20)
            pygame.draw.rect(self.screen, BLACK, bg_rect)
            pygame.draw.rect(self.screen, GREEN, bg_rect, 3)
            self.screen.blit(text, text_rect)
        
        # Draw user info
        self.draw_user_info()
        
        pygame.display.flip()
    
    def play_game_loop(self):
        """Main gameplay loop - THIS WAS THE MISSING FUNCTION"""
        playing = True
        level_complete = False
        
        while playing and self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                    playing = False
                
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        playing = False
                    elif not level_complete:
                        if event.key == pygame.K_w or event.key == pygame.K_UP:
                            self.move_player(0, -1)
                        elif event.key == pygame.K_s or event.key == pygame.K_DOWN:
                            self.move_player(0, 1)
                        elif event.key == pygame.K_a or event.key == pygame.K_LEFT:
                            self.move_player(-1, 0)
                        elif event.key == pygame.K_d or event.key == pygame.K_RIGHT:
                            self.move_player(1, 0)
                        elif event.key == pygame.K_r:
                            # Restart level
                            self.load_level(self.current_level_file)
                        
                        # Check if level is complete
                        if self.check_win() and not level_complete:
                            level_complete = True
                            # Update score
                            if self.score_manager.update_score(self.username, self.moves):
                                print(f"New best score for {self.username}: {self.moves} moves!")
                    else:
                        # Level complete, any key returns to menu
                        playing = False
            
            self.draw_game()
            self.clock.tick(FPS)
    
    def run(self):
        """Main game loop"""
        pygame.quit()
        sys.exit()