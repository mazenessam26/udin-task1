import pygame
import sys
import os
import json

from config import *

# RED = config.RED
# GREEN = config.GREEN
# BLACK = config.BLACK
# WHITE = config.WHITE
# BLUE = config.BLUE
# YELLOW = config.YELLOW
# GRAY = config.GRAY
# DARK_GRAY = config.DARK_GRAY
# BROWN = config.BROWN
# users_db = config.users_db
# WINDOW_WIDTH = config.WINDOW_WIDTH
# WINDOW_HEIGHT = config.WINDOW_HEIGHT
# GRID_WIDTH = config.GRID_WIDTH
# GRID_HEIGHT = config.GRID_HEIGHT
# TILE_SIZE = config.TILE_SIZE
class ScoreManager:
    """Manages leaderboard scores"""
    def __init__(self, filename='scores.json'):
        self.filename = filename
        self.scores = self.load_scores()
    
    def load_scores(self):
        """Load scores from JSON file"""
        try:
            with open(self.filename, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}
    
    def save_scores(self):
        """Save scores to JSON file"""
        try:
            with open(self.filename, 'w') as f:
                json.dump(self.scores, f, indent=2)
        except Exception as e:
            print(f"Error saving scores: {e}")
    
    def update_score(self, username, moves):
        """Update score if it's better (fewer moves)"""
        if username == "anonymous":
            return False
        
        if username not in self.scores or moves < self.scores[username]:
            self.scores[username] = moves
            self.save_scores()
            return True
        return False
    
    def get_leaderboard(self):
        """Get sorted leaderboard (ascending by moves)"""
        return sorted(self.scores.items(), key=lambda x: x[1])







