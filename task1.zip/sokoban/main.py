import pygame
import sys
import os
from pathlib import Path

# Initialize Pygame
pygame.init()

# Constants
TILE_SIZE = 64
GRID_WIDTH = 10
GRID_HEIGHT = 10
WINDOW_WIDTH = GRID_WIDTH * TILE_SIZE
WINDOW_HEIGHT = GRID_HEIGHT * TILE_SIZE
FPS = 60

# Colors (fallback if images not found)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)
BROWN = (139, 69, 19)
YELLOW = (255, 215, 0)
GREEN = (34, 139, 34)
BLUE = (70, 130, 180)
DARK_GREEN = (0, 100, 0)

# Asset loader
def load_image(filename, size=(TILE_SIZE, TILE_SIZE)):
    """Load and scale an image, return None if not found"""
    try:
        # Try loading from assets folder first
        if os.path.exists(os.path.join('assets', filename)):
            img = pygame.image.load(os.path.join('assets', filename))
        # Try loading from current directory
        elif os.path.exists(filename):
            img = pygame.image.load(filename)
        else:
            return None
        return pygame.transform.scale(img, size)
    except:
        return None

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Sokoban Clone")
        self.clock = pygame.time.Clock()
        self.running = True
        
        # Load assets
        self.assets = {
            'player': load_image('player.png'),
            'box': load_image('box.png'),
            'box_on_goal': load_image('box_on_goal.png'),
            'wall': load_image('wall.png'),
            'goal': load_image('goal.png'),
            'floor': load_image('floor.jpg')
        }
        
        # Game state
        self.level = []
        self.player_pos = [0, 0]
        self.boxes = []
        self.goals = []
        self.walls = []
        
        self.load_level("level1.txt")
    
    def load_level(self, filename):
        """Load level from text file"""
        self.level = []
        self.boxes = []
        self.goals = []
        self.walls = []
        
        try:
            with open(filename, 'r') as f:
                lines = f.readlines()
                for y, line in enumerate(lines):
                    row = []
                    for x, char in enumerate(line.rstrip('\n')):
                        row.append(char)
                        pos = [x, y]
                        
                        if char == '@':  # Player
                            self.player_pos = pos
                        elif char == '$':  # Box
                            self.boxes.append(pos)
                        elif char == '*':  # Goal
                            self.goals.append(pos)
                        elif char == '+':  # Box on goal
                            self.boxes.append(pos)
                            self.goals.append(pos)
                        elif char == '#':  # Wall
                            self.walls.append(pos)
                    
                    self.level.append(row)
        except FileNotFoundError:
            # Create default level if file not found
            self.create_default_level()
    
    def create_default_level(self):
        """Create a simple default level"""
        default = [
            "##########",
            "#        #",
            "#  @     #",
            "#  $  *  #",
            "#  $  *  #",
            "#        #",
            "##########"
        ]
        
        for y, line in enumerate(default):
            row = []
            for x, char in enumerate(line):
                row.append(char)
                pos = [x, y]
                
                if char == '@':
                    self.player_pos = pos
                elif char == '$':
                    self.boxes.append(pos)
                elif char == '*':
                    self.goals.append(pos)
                elif char == '#':
                    self.walls.append(pos)
            
            self.level.append(row)
    
    def move_player(self, dx, dy):
        """Handle player movement and box pushing"""
        new_x = self.player_pos[0] + dx
        new_y = self.player_pos[1] + dy
        new_pos = [new_x, new_y]
        
        # Check if moving into wall
        if new_pos in self.walls:
            return
        
        # Check if moving into box
        if new_pos in self.boxes:
            # Check if we can push the box
            box_new_x = new_x + dx
            box_new_y = new_y + dy
            box_new_pos = [box_new_x, box_new_y]
            
            # Can't push if box would go into wall or another box
            if box_new_pos in self.walls or box_new_pos in self.boxes:
                return
            
            # Push the box
            box_index = self.boxes.index(new_pos)
            self.boxes[box_index] = box_new_pos
        
        # Move player
        self.player_pos = new_pos
    
    def check_win(self):
        """Check if all boxes are on goals"""
        for box in self.boxes:
            if box not in self.goals:
                return False
        return True
    
    def draw(self):
        """Draw the game state"""
        self.screen.fill(BLACK)
        
        # Draw floor
        for y in range(len(self.level)):
            for x in range(len(self.level[y])):
                rect = pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                
                # Use floor image if available, otherwise use gray color
                if self.assets['floor']:
                    self.screen.blit(self.assets['floor'], (x * TILE_SIZE, y * TILE_SIZE))
                else:
                    pygame.draw.rect(self.screen, GRAY, rect)
                    pygame.draw.rect(self.screen, BLACK, rect, 2)
        
        # Draw goals
        for goal in self.goals:
            if self.assets['goal']:
                self.screen.blit(self.assets['goal'], (goal[0] * TILE_SIZE, goal[1] * TILE_SIZE))
            else:
                rect = pygame.Rect(goal[0] * TILE_SIZE + 10, goal[1] * TILE_SIZE + 10, 
                                 TILE_SIZE - 20, TILE_SIZE - 20)
                pygame.draw.rect(self.screen, DARK_GREEN, rect)
                pygame.draw.circle(self.screen, GREEN, 
                                 (goal[0] * TILE_SIZE + TILE_SIZE // 2, 
                                  goal[1] * TILE_SIZE + TILE_SIZE // 2), 
                                 TILE_SIZE // 3)
        
        # Draw walls
        for wall in self.walls:
            if self.assets['wall']:
                self.screen.blit(self.assets['wall'], (wall[0] * TILE_SIZE, wall[1] * TILE_SIZE))
            else:
                rect = pygame.Rect(wall[0] * TILE_SIZE, wall[1] * TILE_SIZE, 
                                 TILE_SIZE, TILE_SIZE)
                pygame.draw.rect(self.screen, BROWN, rect)
                pygame.draw.rect(self.screen, BLACK, rect, 3)
        
        # Draw boxes
        for box in self.boxes:
            # Use different image if box is on goal
            if box in self.goals:
                if self.assets['box_on_goal']:
                    self.screen.blit(self.assets['box_on_goal'], (box[0] * TILE_SIZE, box[1] * TILE_SIZE))
                else:
                    rect = pygame.Rect(box[0] * TILE_SIZE + 8, box[1] * TILE_SIZE + 8, 
                                     TILE_SIZE - 16, TILE_SIZE - 16)
                    pygame.draw.rect(self.screen, YELLOW, rect)
                    pygame.draw.rect(self.screen, BLACK, rect, 3)
            else:
                if self.assets['box']:
                    self.screen.blit(self.assets['box'], (box[0] * TILE_SIZE, box[1] * TILE_SIZE))
                else:
                    rect = pygame.Rect(box[0] * TILE_SIZE + 8, box[1] * TILE_SIZE + 8, 
                                     TILE_SIZE - 16, TILE_SIZE - 16)
                    pygame.draw.rect(self.screen, BROWN, rect)
                    pygame.draw.rect(self.screen, BLACK, rect, 3)
        
        # Draw player
        if self.assets['player']:
            self.screen.blit(self.assets['player'], (self.player_pos[0] * TILE_SIZE, self.player_pos[1] * TILE_SIZE))
        else:
            player_rect = pygame.Rect(self.player_pos[0] * TILE_SIZE + 12, 
                                     self.player_pos[1] * TILE_SIZE + 12, 
                                     TILE_SIZE - 24, TILE_SIZE - 24)
            pygame.draw.rect(self.screen, BLUE, player_rect)
            pygame.draw.rect(self.screen, WHITE, player_rect, 3)
        
        # Draw win message if complete
        if self.check_win():
            font = pygame.font.Font(None, 74)
            text = font.render("Level Complete!", True, WHITE)
            text_rect = text.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2))
            # Draw background for text
            bg_rect = text_rect.inflate(20, 20)
            pygame.draw.rect(self.screen, BLACK, bg_rect)
            pygame.draw.rect(self.screen, GREEN, bg_rect, 3)
            self.screen.blit(text, text_rect)
        
        pygame.display.flip()
    
    def handle_events(self):
        """Handle keyboard input"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w:
                    self.move_player(0, -1)
                elif event.key == pygame.K_s:
                    self.move_player(0, 1)
                elif event.key == pygame.K_a:
                    self.move_player(-1, 0)
                elif event.key == pygame.K_d:
                    self.move_player(1, 0)
                elif event.key == pygame.K_ESCAPE:
                    self.running = False
    
    def run(self):
        """Main game loop"""
        while self.running:
            self.handle_events()
            self.draw()
            self.clock.tick(FPS)
        
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = Game()
    game.run()